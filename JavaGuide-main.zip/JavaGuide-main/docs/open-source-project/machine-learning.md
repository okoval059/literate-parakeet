---
title: Java 优质开源机器学习项目
category: 开源项目
icon: a-MachineLearning
---

- **[Deeplearning4j](https://github.com/eclipse/deeplearning4j)**：Deeplearning4j 是第一个为 Java 和 Scala 编写的商业级，开源，分布式深度学习库。
- **[Smile](https://github.com/haifengl/smile)**：基于 Java 和 Scala 的机器学习库。

相关阅读：[Java 能用于机器学习和数据科学吗？-InfoQ](https://www.infoq.cn/article/GA9UeYlv8ohBzBso9eph)

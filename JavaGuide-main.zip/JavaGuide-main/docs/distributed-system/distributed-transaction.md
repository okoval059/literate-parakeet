---
title: 分布式事务常见解决方案总结(付费)
category: 分布式
---

**分布式事务** 相关的面试题为我的[知识星球](https://javaguide.cn/about-the-author/zhishixingqiu-two-years.html)（点击链接即可查看详细介绍以及加入方法）专属内容，已经整理到了《Java 面试指北》中。

![](https://oss.javaguide.cn/javamianshizhibei/distributed-system.png)

<!-- @include: @planet.snippet.md -->

<!-- @include: @article-footer.snippet.md -->
---
title: 某培训机构盗我文章做成视频还上了B站热门
category: 走近作者
tag:
  - 杂谈
---

时间回到 2021-02-25，我在刷哔哩哔哩的时候发现，哔哩哔哩某 UP 主（某培训机构），擅自将我在知乎的一个回答做成了视频。

原滋原味啊！我艹。甚至，连我开头的自我调侃还加上了！真的牛皮！

你盗我原创，视频你用心做好点也行啊！至少也可以让这么优质的内容得到传播嘛！

结果，好家伙，视频做的像坨屎一样，配音也贼违和!

麻烦这个培训机构看到这篇文章之后可以考虑换一个人做类似恶心的事情哈！这人完全没脑子啊！

![](https://oss.javaguide.cn/github/javaguide/about-the-author/up-db6b9cf323930786fa2bec8b1e1bfaad732.png)

![](https://oss.javaguide.cn/github/javaguide/about-the-author/up-6395603ab441b74511c6eda28efee8937d7.png)

![](https://oss.javaguide.cn/github/javaguide/about-the-author/up-921f60a5c7cee2c5c2eb30f4f7048f648e1.png)

![](https://oss.javaguide.cn/github/javaguide/about-the-author/up-acc82a797bd01e27f5b7d5d327b32a21d4e.png)

我随便找了一个视频看，发现也还是盗用别人的原创。

![](https://oss.javaguide.cn/github/javaguide/about-the-author/up-48d0c5ab086265ae19b7396bc59de2c2daf.png)

![](https://oss.javaguide.cn/github/javaguide/about-the-author/up-366abf0656007ff96551064104e60740a41.png)

其他的视频就不用多看了，是否还是剽窃别人的原创，原封不动地做成视频，大家心里应该有数。

他们这样做的目的就是一个：**引流到自己的 QQ 群，然后忽悠你买课程。**

我并不认为是这完全都是培训机构的问题。培训机构的员工为了流量而做这种恶心的事情，也导致了现在这种事情被越来越频繁地发生。

所以，你会发现，哔哩哔哩和知乎上有越来越多培训机构的小号，到处剽窃原创，盗发。

我身边很多原创号主的文章都经常被某些培训机构盗发。

有时候真的会比较生气，毕竟你自己辛辛苦苦的原创，别人复制粘贴一下就白嫖了！

但是，我相信，这种靠剽窃别人原创来吸引流量的行为，终究只是跳梁小丑的行为罢了！

只有那些用心输出内容的创作者，才能走的更远，更安稳！

后来，我在我的公众号上发了一篇名为[《好家伙！某培训机构盗我文章做成视频还上了热门》](https://mp.weixin.qq.com/s?__biz=Mzg2OTA0Njk0OA==&mid=2247500005&idx=1&sn=7351e22619654492d3cf567bff9d87f0&chksm=cea18f2ef9d606384e0265b9318e004646c03b8a69f2801698d2f9e0e6bdfec0a1185ac3ab17&token=2146952532&lang=zh_CN&scene=21#wechat_redirect) 的文章，吐槽自己的原创被某机构白嫖。

谁能想到，培训机构的人竟然找人来让我删文章了！讲真，这俩人是真的奇葩啊！

![](https://oss.javaguide.cn/github/javaguide/about-the-author/8f8ccafcf5b764a2289a9c276c30728d.png)

![](https://oss.javaguide.cn/javaguide/a0a4a45d7ec7b1a2622b2a38629e9b09.png)

还让我格局大点？我去你丫的！明明就是我的原创，你自己不删，反而找人联系我删除！有脑子不？

其实，我这人是比较好说话的，现实生活中脾气也是出了名的好（前提是没有触犯到我的原则的情况）。

搞笑的是！他们在让我删文的同时，他们 B 站盗发的视频还都在，还在继续为他们引流。

![](https://oss.javaguide.cn/javaguide/86f659a93ce5b639526c8d2bd20b2fbe.png)

![](https://oss.javaguide.cn/github/javaguide/about-the-author/be6e0fd23146de3f6224b4d853c59ce7.png)

如果他们把账号注销了，我或许还能考虑放一手。但是，文章是肯定不会删的。

现在，看后续情况吧！我随时可以动用法律来维护自己的权益，只是看我想不想，毕竟也挺麻烦对吧！

大家不用担心，这都是小事，我女朋友就是学法律的，国内的某法学双一流学校。

咱不怕事！凎！！！

import { arraySidebar } from "vuepress-theme-hope";

export const books = arraySidebar([
  {
    text: "计算机基础",
    link: "cs-basics",
    icon: "computer",
  },
  {
    text: "数据库",
    link: "database",
    icon: "database",
  },
  {
    text: "搜索引擎",
    link: "search-engine",
    icon: "search",
  },
  {
    text: "Java",
    link: "java",
    icon: "java",
  },
  {
    text: "软件质量",
    link: "software-quality",
    icon: "highavailable",
  },

  {
    text: "分布式",
    link: "distributed-system",
    icon: "distributed-network",
  },
]);
